#include <vector>
#include "util.h"

using namespace std;

void ompNumeric_Multiplication(crsMatrix& mtx1, crsMatrix& mtx2, crsMatrix& mtx3)
{
  int i,j,k;
  clock_t start, finish;
  int order = mtx1.N;
  
  memset(mtx3.Value, 0, mtx3.NZ * sizeof(double));
  Transpose(mtx2);

  for(i = 0; i < order; i++)
  {
    for(j = mtx1.RowIndex[i]; j < mtx1.RowIndex[i + 1]; j++)
    {
      int colJ = mtx1.Col[j];
      for(k = mtx2.RowIndex[colJ]; k < mtx2.RowIndex[colJ + 1]; k++)
      {
        int colK = mtx2.Col[k];

		double tmpSum = mtx1.Value[j] * mtx2.Value[k];
        int startI = mtx3.RowIndex[i];
        int endI = mtx3.RowIndex[i + 1] - 1;
        int index = endI;

        while((startI < endI)&&(mtx3.Col[index] != colK))
        {
          index = (startI + endI) / 2;
          if(mtx3.Col[index] > colK)
            endI = index;
          else
          {
            if(mtx3.Col[index] < colK)
              startI = index + 1;
          }
        }
        mtx3.Value[index] += tmpSum;
      }
    }
  }

}

void ompParallelSymbolicMultiplication(crsMatrix& mtx1, crsMatrix& mtx2, vector<int>* &res_columns)
{
	#pragma omp parallel for
	for(int i = 0; i < mtx1.N; i++)
	{
		for(int j = 0; j < mtx1.N; j++)
		{
			int isBreaked = 0;
			int start = mtx2.RowIndex[j];
			for(int k = mtx1.RowIndex[i]; k < mtx1.RowIndex[i + 1]; k++)
			{
				for(int l = start; l < mtx2.RowIndex[j + 1]; l++)
				{
					if(mtx1.Col[k] == mtx2.Col[l])
					{
						res_columns[i].push_back(j);
						isBreaked = 1;
						start = l + 1;
						break;
					}
					else
					{
						if(mtx1.Col[k] < mtx2.Col[l])
						{
							break;
						}
					}
				}
				if(isBreaked == 1)
					break;
			}
		}
	}
}


void ompMMult(crsMatrix& mtx1, crsMatrix& mtx2, crsMatrix& mtx3)
{
	int n = mtx1.N;
	vector<int>* res_columns = new vector<int>[n];

    Transpose(mtx2);
    ompParallelSymbolicMultiplication(mtx1, mtx2, res_columns);

    int* row_index = new int[n + 1];
    int sum = 0;
    for(int i = 0; i < n; i++)
    {
      row_index[i] = sum;
      sum += res_columns[i].size();
    }

    row_index[n] = sum;
    mtx3.N = n;
    mtx3.NZ = sum;
    mtx3.RowIndex = row_index;
    mtx3.Col = new int[sum];
    mtx3.Value = new double[sum];

    int gen_counter = 0;
    for(int i = 0; i < n; i++)
    {
      for(int j = 0; j < res_columns[i].size(); j++)
      {
        mtx3.Col[gen_counter] = res_columns[i][j];
        gen_counter++;
      }
    }

    ompNumeric_Multiplication(mtx1, mtx2, mtx3);
}
