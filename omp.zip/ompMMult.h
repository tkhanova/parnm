#include "util.h"

void ompMMult(crsMatrix& mtx1, crsMatrix& mtx2, crsMatrix& mtx3);