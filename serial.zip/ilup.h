#pragma once

#include <stdio.h>
#include <string.h>
#include <queue>
#include <math.h>
#include "type.h"

int symbolicILUp2(int p, int n, int * col, int * row, 
                 int * &lucol, int * &lurow, double * &luval,
                 int * uptr, int &countL, int &countU);

int numericalILUp(int n, double * a, int * col, int * row, 
                  int * lucol, int * lurow, int * uptr,
                  double * luval);