#include "productSparseMatrix.h"
#include <iostream>
#include "tbbMMult.h"
//#include "ompMMult.h"
//#include "cilkMMult.h"

using namespace std;

void MMultSerial(crsMatrix &A, crsMatrix &B, crsMatrix &C)
{
  int order = A.N;
  vector<int> columns;
  vector<double> values;
  vector<int> row_index;

  Transpose(B);

  int numNZ_row;
  row_index.push_back(0);
  for(int i = 0; i < order; i++)
  {
	  numNZ_row = 0;   
	  for(int j = 0; j < order; j++)
	  {
		  double sum = 0;
		  int isFounded = 0;
		  for(int k = A.RowIndex[i]; k < A.RowIndex[i + 1]; k++)
		  {
			  for(int l = B.RowIndex[j]; l < B.RowIndex[j + 1]; l++)
			  {
				  if(A.Col[k] == B.Col[l])
				  {
					  sum += A.Value[k] * B.Value[l];
					  isFounded = 1;
					  break;
				  }
			  }
		  }
		  if(isFounded == 1)
		  {
			  columns.push_back(j);
			  values.push_back(sum);
			  numNZ_row++;
		  }
	  }
	  row_index.push_back(numNZ_row + row_index[i]);
  }

  InitializeMatrix(order, columns.size(), C);

  for(int j = 0; j < columns.size(); j++)
  {
    (C).Col[j] = columns[j];
    (C).Value[j] = values[j];
  }
  for(int i = 0; i <=order; i++)
    C.RowIndex[i] = row_index[i];
}

void ProductSparseMatrix(crsMatrix &A, crsMatrix &B, crsMatrix &C)
{
	//MMultSerial(A,B,C);
	tbbMMult(A, B,C);
	//ompMMult(A, B,C);
	//cilkMMult(A, B,C);
}


