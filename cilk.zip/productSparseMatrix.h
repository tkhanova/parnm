#pragma once
#include "util.h"


void ProductSparseMatrix (crsMatrix &A,  crsMatrix &B, 
                          crsMatrix &C);
