#ifndef __UTIL_H__
#define __UTIL_H__

#include "type.h"
#include <math.h>
#include <memory.h>
#include <stdlib.h>
#include <time.h>
#include <vector>

void InitializeMatrix	(int N, int NZ, crsMatrix &mtx);

void FreeMatrix(crsMatrix &mtx);

void CopyMatrix(crsMatrix imtx, crsMatrix &omtx);

void Transpose(crsMatrix &mtx);

void LUmatrixSeparation (crsMatrix ilu, int *uptr, 
                         crsMatrix &L, crsMatrix &U);

crsMatrix* UpTriangleMatrixToFullSymmetricMatrix( const crsMatrix* const A );

#endif // __UTIL_H__