#include "util.h"

void cilkMMult(crsMatrix& mtx1, crsMatrix& mtx2, crsMatrix& mtx3);