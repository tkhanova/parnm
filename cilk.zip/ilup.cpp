#include "ilup.h"
#include "util.h"

using namespace std;

#include "productSparseMatrix.h"

int symbolicILUp2 (int p, int n, int* col, int* row,
                   int* &lucol, int* &lurow, double* &luval,
                   int* uptr, int &countL, int &countU) 
{
	if (lucol != NULL) {
        delete []lucol;
    }
    
    if (lurow != NULL) {
        delete []lurow;
    }
    
    if (luval != NULL) {
        delete []luval;
    }

	int nz = row[n];
	crsMatrix C;

	C.N=n;
	C.RowIndex=0;

	if(p==0)
	{
		C.Col = new int[nz];
		memcpy(C.Col, col, sizeof(int)*nz);

		C.RowIndex = new int[n+1];
		memcpy(C.RowIndex, row, sizeof(int)*(n+1));

		C.NZ=nz;
	}
	else
	{
		double* val = new double[nz];

		for(int i=0; i<nz; i++)
			val[i]=1.;

		crsMatrix A, B;

		B.RowIndex=0;
		B.Col=0;
		B.Value=0;

		A.Col=col;
		A.N=n;
		A.NZ=nz;
		A.RowIndex=row;
		A.Value=val;

		ProductSparseMatrix(A,A,C);

		for(int i=2; i<p+1; i++)
		{
			FreeMatrix(B);

			B=C;
			memset(&C,0,sizeof(C));
			ProductSparseMatrix(A,B,C);
		}

		delete[] val;
	}

	lucol=C.Col;
	lurow=C.RowIndex;
	luval = new double[C.NZ];
	memset (luval, 0, (C.NZ) * sizeof (double));

	countL=0;
	countU=0;

	for (int i = 0; i < n; i++) 
	{
		int s = lurow[i];
		int f = lurow[i + 1];
		int j;

		for (j = s; j < f; j++) 
		{
			int jcol = lucol[j];

			if (jcol < i) 
				countL++;
			else
				break;
		}

		countU += (f - j);

		uptr[i] = j;        
	}

	return ILU_OK;
}

int numericalILUp (int n, double* a, int* col, int* row,
                   int* lucol, int* lurow, int* uptr,
                   double* luval) {
    int j1, j2;     // ������� ������� ������
    int jrow;       // ����� �������� �������
    int k, j, jj;   // �������� ������+
    int* iw = NULL;
    int jw;
    double t1;
    iw = new int[n];
    memset (iw, 0, n * sizeof (int));
    //����������� �������� �������
    j = 0;
    
    for (k = 0; k < row[n]; k++) {
        j1 = col[k];
        j2 = lucol[k + j];
        
        while (j1 != j2) {
            j++;
            j2 = lucol[k + j];
        }
        
        luval[k + j] = a[k];
    }
    
    for (k = 0; k < n; k++) {
        j1 = lurow[k];
        j2 = lurow[k + 1];
        
        for (j = j1; j < j2; j++) {
            iw[lucol[j]] = j;
        }
        
        for (j = j1; (j < j2) && (lucol[j] < k); j++) {
            jrow = lucol[j];
            t1 = luval[j] / luval[uptr[jrow]];
            luval[j] = t1;
            
            for (jj = uptr[jrow] + 1; jj < lurow[jrow + 1]; jj++) {
                jw = iw[lucol[jj]];
                
                if (jw != 0) {
                    luval[jw] = luval[jw] - t1 * luval[jj];
                }
            }
        }
        
        jrow = lucol[j];
        
        if ( (jrow != k) || (fabs (luval[j]) < EPSILON)) {
            break;
        }
        
        for (j = j1; j < j2; j++) {
            iw[lucol[j]] = 0;
        }
    }
    
    delete [] iw;
    
    if (k < n)
        return - (k + 1);
        
    return 0;
}