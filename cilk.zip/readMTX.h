#pragma once
#include <stdio.h>
#include "type.h"

int ReadMatrixFromFile(char* matrixName, int* n, int* nz, int** column, 
             int** row, FLOAT_TYPE** val, int *typeOfMatrix);

