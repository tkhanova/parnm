#include "util.h"
#include <iostream>

using namespace std;

// ������� ���������� ������� � ������� CRS (3 �������, ���������� � ����)
// �������� ������ ��� ���� Value, Col � RowIndex
// ���������� ����� �������� mtx
void InitializeMatrix(int N, int NZ, crsMatrix &mtx)
{
  mtx.N = N;
  mtx.NZ = NZ;
  mtx.Value  = new double[NZ];
  mtx.Col    = new int[NZ];
  mtx.RowIndex = new int[N + 1];
}

// ����������� ������, ���������� ��� ���� mtx
void FreeMatrix(crsMatrix &mtx)
{
	if(mtx.Value)
		delete [] mtx.Value;
	mtx.Value=0;

	if(mtx.Col)
		delete [] mtx.Col;
	mtx.Col=0;

	if(mtx.RowIndex)
		delete [] mtx.RowIndex;
	mtx.RowIndex=0;
}

// ������� ����� imtx � omtx, ������� ������ ��� ���� Value, Col � RowIndex
void CopyMatrix(crsMatrix imtx, crsMatrix &omtx)
{
  // ������������� �������������� �������
  int N  = imtx.N;
  int NZ = imtx.NZ;
  InitializeMatrix(N, NZ, omtx);
  // �����������
  memcpy(omtx.Value   , imtx.Value   , NZ * sizeof(double));
  memcpy(omtx.Col   , imtx.Col   , NZ * sizeof(int));
  memcpy(omtx.RowIndex, imtx.RowIndex, (N + 1) * sizeof(int));
}



void Transpose(crsMatrix &mtx)
{
  vector<int>* columns = new vector<int>[(mtx).N];
  vector<double> *values = new vector<double>[(mtx).N];

  for(int i = 0; i < (mtx).N; i++)
  {
    for(int j = (mtx).RowIndex[i]; j < (mtx).RowIndex[i + 1]; j++)
    {
      columns[(mtx).Col[j]].push_back(i);
      values[(mtx).Col[j]].push_back((mtx).Value[j]);
    }
  }

  int genCounter = 0;
  for(int i = 0; i < (mtx).N; i++)
  {
    for(int j = 0; j < columns[i].size(); j++)
    {
      (mtx).Col[genCounter] = columns[i][j];
      (mtx).Value[genCounter] = values[i][j];
      genCounter++;
    }
  }

  (mtx).RowIndex[0] = 0;
  int sum = int(columns[0].size());
  for(int i = 1; i < (mtx).N; i++)
  {
    (mtx).RowIndex[i] = sum;
    sum += int(columns[i].size());
  }
  (mtx).RowIndex[(mtx).N] = (mtx).NZ;

  delete[] columns;
  delete[] values;
}



void LUmatrixSeparation(crsMatrix ilu, int *uptr, crsMatrix &L, crsMatrix &U)
{
  int countL, countU;
  int i, j, s, f, k;
  double *val;
  int    *col;
  countU = 0;
  for(i = 0; i < ilu.N; i++)
  {
    countU += (ilu.RowIndex[i+1] - uptr[i]);
  }
  countL = ilu.NZ + ilu.N - countU;
  InitializeMatrix(ilu.N, countL, L);
  InitializeMatrix(ilu.N, countU, U);
  // fill L matrix
  k = 0;
  val = L.Value;
  col = L.Col;
  L.RowIndex[0] = k;
  for(i = 0; i < ilu.N; i++)
  {
    s = ilu.RowIndex[i];
    f = uptr[i];
    for(j = s; j < f; j++)
    {
      val[k] = ilu.Value[j];
      col[k] = ilu.Col[j];
      k++;
    }
    val[k] = 1.0;
    col[k] = i;
    k++;
    L.RowIndex[i + 1] = k;
  }
  // fill U matrix
  k = 0;
  val = U.Value;
  col = U.Col;
  U.RowIndex[0] = k;
  for(i = 0; i < ilu.N; i++)
  {
    s = uptr[i];
    f = ilu.RowIndex[i + 1];
    for(j = s; j < f; j++)
    {
      val[k] = ilu.Value[j];
      col[k] = ilu.Col[j];
      k++;
    }
    U.RowIndex[i + 1] = k;
  }
}


crsMatrix* UpTriangleMatrixToFullSymmetricMatrix( const crsMatrix* const A )
{
	crsMatrix* FullA;
	int countElementsInRowA = 0;
	int* countElementsInRows = new int[ A->N ];
	int* currentPostitionsInRow = new int[ A->N ];

	FullA = new crsMatrix;

	InitializeMatrix( A->N, (A->NZ * 2 - A->N), *FullA);
	
	for( int i = 0; i < A->N; i++ )
	{
		countElementsInRows[ i ] = 0;
		currentPostitionsInRow[ i ] = 0;
	}

	for( int i = 0; i < A->N; i++ )
	{
		for( int k = A->RowIndex[ i ] + 1; k < A->RowIndex[ i + 1 ]; k++ )
		{
			countElementsInRows[ A->Col[ k ] ]++;
		}
	}
	FullA->RowIndex[ 0 ] = 0;
	for( int i = 1; i <= A->N; i++ )
	{
		countElementsInRowA = A->RowIndex[ i ] - A->RowIndex[ i - 1 ];
		FullA->RowIndex[ i ] = FullA->RowIndex[ i - 1 ] + countElementsInRowA + countElementsInRows[ i - 1 ];
		currentPostitionsInRow[ i - 1 ] = FullA->RowIndex[ i - 1 ];
	}
	
	for( int i = 0; i < A->N; i++ )
	{
		for( int j = A->RowIndex[ i ] + 1; j < A->RowIndex[ i + 1 ] ; j++ )
		{
			FullA->Value[ currentPostitionsInRow[ A->Col[ j ] ] ] = A->Value[ j ];
			FullA->Col[ currentPostitionsInRow[ A->Col[ j ] ] ] = i;
			currentPostitionsInRow[ A->Col[ j ] ]++;
		}
	}

	for( int i = 0; i < A->N; i++ )
	{
		for( int j = A->RowIndex[ i ]; j < A->RowIndex[ i + 1 ]; j++ )
		{
			FullA->Value[ currentPostitionsInRow[ i ] ] = A->Value[ j ];
			FullA->Col[ currentPostitionsInRow[ i ] ] = A->Col[ j ];
			currentPostitionsInRow[ i ]++;
		}
	}

	delete[] currentPostitionsInRow;
	delete[] countElementsInRows;
	return FullA;
}

