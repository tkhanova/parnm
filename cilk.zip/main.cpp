#include "timer.h"
#include "ilup.h"
#include <iostream>
#include <fstream>
#include "readMTX.h"
#include "productSparseMatrix.h"
#include <stdio.h>

using namespace std;

void PrintInFile(crsMatrix *mtx, char * file)
{
	FILE *res=fopen(file, "w");

	int nz = 0;

	fprintf(res, "%d %d %d\n", mtx->N, mtx->N, mtx->NZ);

	for (int i = 0; i < mtx->N; i++) 
	{
		int s = mtx->RowIndex[i];
		int f = mtx->RowIndex[i + 1];

		for (int j = s; j < f; j++) 
		{
			int jcol = mtx->Col[j];

			fprintf(res, "%d %d %lf\n", i+1, jcol+1, mtx->Value[j]);
		}
	}

	fclose(res);
}


//#include "tbb/task_scheduler_init.h"

int main(int argc, char*argv[])
{
	//tbb::task_scheduler_init init(1);

	int error;
	crsMatrix readA;
	crsMatrix *matA;
	int typeOfMatrix;

	error = ReadMatrixFromFile ( argv[1], & ( readA.N ), & ( readA.NZ ),
                                 & ( readA.Col ), & ( readA.RowIndex ), & ( readA.Value ),
                                 & ( typeOfMatrix ) );
                                 

	cout << "typeOfMatrix = " << typeOfMatrix << endl;
	cout << "N = " << readA.N << endl;
	cout << "NZ = " << readA.NZ << endl;

	if ( error != ILU_OK ) 
	{
        printf ( "error read matrix %d\n", error );
        return error;
    }
    
    // ���� ������� ������������ � ������ ������ ������� �������������,
    // �� ��������� �� �� ������
    if ( typeOfMatrix == UPPER_TRIANGULAR ) 
        matA = UpTriangleMatrixToFullSymmetricMatrix ( &readA );
     else 
        matA = &readA;
    
	int p = 1, n;
	int countL;
    int countU;
	crsMatrix L;
    crsMatrix U;
    crsMatrix M;
	crsMatrix lu;
	int *uptr;
	double diff;

	n = matA->N;

	uptr = new int[n];

	lu.Col      = NULL;
    lu.RowIndex = NULL;
    lu.Value    = NULL;

	Timer timer;

	timer.start();	
	symbolicILUp2 ( p, matA->N, matA->Col, matA->RowIndex,
                       lu.Col, lu.RowIndex, lu.Value,
                       uptr, countL, countU );
    lu.N = matA->N;
    lu.NZ = countL + countU;
           
    if ( error != ILU_OK ) {
        printf ( "ilu symbolic factorization %d\n", error );
        return -1;
    }
        
    error = numericalILUp ( matA->N, matA->Value, matA->Col, matA->RowIndex,
                            lu.Col, lu.RowIndex, uptr, lu.Value );     
	timer.stop();

	printf ( "Count elements: L NZ(%d) U NZ(%d) \n", countL + n, countU );

    if ( error != ILU_OK ) {
        printf ( "ilu factorization %d\n", error );
        return -1;
    }
        
    // ���������� ������� �� L � U
    LUmatrixSeparation ( lu, uptr, L, U );
    // ����������� �������	
    ProductSparseMatrix ( L, U, M );

	//PrintInFile ( &L , "L.mtx");
	//PrintInFile ( &U , "U.mtx");
	PrintInFile(&M, argv[2]);

	delete[] uptr; 

	FreeMatrix(*matA);
	FreeMatrix(readA);
	FreeMatrix(L);
	FreeMatrix(U);
	FreeMatrix(M);
	
	std::ofstream timeLog;
	timeLog.open(argv[3]);
	timeLog << timer.getElapsed();
	
	return 0;
}